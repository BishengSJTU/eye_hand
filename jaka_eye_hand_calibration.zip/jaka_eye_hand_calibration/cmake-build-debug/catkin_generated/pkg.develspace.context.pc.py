# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel/include".split(';') if "/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "cv_bridge;image_transport;roscpp;std_msgs;tf;sensor_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "jaka_eye_hand_calibration"
PROJECT_SPACE_DIR = "/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
