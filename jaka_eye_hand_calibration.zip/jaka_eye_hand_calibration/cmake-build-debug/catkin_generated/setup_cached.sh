#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel/lib:$LD_LIBRARY_PATH"
export PATH="/opt/ros/kinetic/bin:/opt/pycharm-community-2019.2.2/bin:/opt/clion-2019.2/bin:/home/iqr/bin:/home/iqr/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
export PKG_CONFIG_PATH="/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/aemc4/catkin_bisheng/src/image_processing/pose_estimation:/home/iqr/catkin_robotiq/src/pose_estimation:/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration:$ROS_PACKAGE_PATH"