#include "robot_client_tcp.h"
#include "jaka_eye_hand_calibration/RobotMsg.h"
#include <ros/ros.h>
#define PI 3.1415926

int main(int argc, char **argv)
{
    ros::init(argc, argv, "pose_publisher");
    RobotClient robotclient("192.168.33.3");
    ros::Publisher jaka_pub;
    std::vector<float> joint;
    std::vector<float> cart;
    jaka_eye_hand_calibration::RobotMsg robot_msg;
    ros::NodeHandle nh;
    while(ros::ok()) {
        robotclient.GetRobotPose(joint, cart);
        jaka_pub = nh.advertise<jaka_eye_hand_calibration::RobotMsg>("jaka_pose", 1);
        robot_msg.cart_vector.clear();
        robot_msg.joint_vector.clear();
        for (int i = 0; i < cart.size(); i++) {
            robot_msg.cart_vector.push_back(cart[i]);
            robot_msg.joint_vector.push_back(joint[i]);
        }
        jaka_pub.publish(robot_msg);
        ros::spinOnce();
    }
    return 0;
}
