#include <iostream>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/CameraInfo.h>
#include <sensor_msgs/Image.h>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <Eigen/Dense>
#include <Eigen/QR>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "jaka_eye_hand_calibration/RobotMsg.h"


using namespace cv;
using namespace std;

class Eye_Hand_Calibration_Capture {
private:
    ros::NodeHandle nh_;
    image_transport::ImageTransport it_;
    image_transport::Subscriber image_sub_color;//接收彩色图像
    ros::Subscriber robot_pose_info_sub_;

    Mat colorImage;
    jaka_eye_hand_calibration::RobotMsg msg;
    vector<double> cur_cart;

    int num;
    string filePath;
    ofstream out;

public:

    Eye_Hand_Calibration_Capture() : it_(nh_), cur_cart(6, 0.0), num( 0 ),
    filePath( "/home/iqr/catkin_robotiq/src/jaka_eye_hand_calibration/data/"), out(filePath + "pose.txt") {
        //topic sub:
        image_sub_color = it_.subscribe("/camera/color/image_raw", 1,
                                        &Eye_Hand_Calibration_Capture::imageColorCb, this);
        robot_pose_info_sub_ = nh_.subscribe("jaka_pose", 1,
                                             &Eye_Hand_Calibration_Capture::robotPoseCb, this);
        namedWindow("colorImage");
    }
    ~Eye_Hand_Calibration_Capture() {
        destroyWindow("colorImage");
    }

    void imageColorCb(const sensor_msgs::ImageConstPtr &msg) {
        cv_bridge::CvImagePtr cv_ptr;
        try {
            cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
            colorImage = cv_ptr->image;
        } catch (cv_bridge::Exception &e) {
            ROS_ERROR("cv_bridge exception: %s", e.what());
            return;
        }

        Mat showImage = colorImage.clone();
        cv::resize(showImage, showImage, cv::Size(showImage.cols / 4, showImage.rows / 4), 0, 0,
                   cv::INTER_LINEAR);
        imshow("colorImage", showImage);
        char ch = waitKey(1);
        if (ch == 's') {

            num = num + 1;
            string image_name;
            stringstream ss1, ss2;
            ss1 << num << "_color.png";
            ss1 >> image_name;

            imwrite(filePath + image_name, colorImage);

            Eigen::Quaternionf m = Eigen::AngleAxisf(cur_cart[5] / 180 * M_PI, Eigen::Vector3f::UnitZ())\
                                    * Eigen::AngleAxisf(cur_cart[4] / 180 * M_PI, Eigen::Vector3f::UnitY())\
                                    * Eigen::AngleAxisf(cur_cart[3] / 180 * M_PI, Eigen::Vector3f::UnitX());
            out << num << " " << cur_cart[0] << " " << cur_cart[1] << " " << cur_cart[2] << "  " << m.x() << " "
                << m.y() << " " << m.z() << " " << m.w() << endl;
            cout << "save robot pose: " << num << "  " << cur_cart[0] << " " << cur_cart[1] << " " << cur_cart[2]
                 << "  " << cur_cart[3] << " " << cur_cart[4] << " " << cur_cart[5] << endl;
        } else if(ch == 'q') {
            return;
        }
        return;
    }

    void robotPoseCb(const jaka_eye_hand_calibration::RobotMsg &msg) {
        cur_cart = msg.cart_vector;
        return;
    }

    void setNum(const int myNum) {
        num = myNum - 1;
    }
};

int main( int argc, char **argv ) {
    cout << "------------Starting to capture----------" << endl;
    ros::init(argc, argv, "eye_hand_calibration_capture");
//    int num = stoi(string(argv[1]));
    Eye_Hand_Calibration_Capture eyeHandCalibrationCapture;
    ros::spin();
    return (0);
}

